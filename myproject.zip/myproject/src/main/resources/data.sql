insert into article(title, content) values('오늘의날씨', '맑음');
insert into article(title, content) values('내일의날씨', '흐림');
insert into article(title, content) values('모레의날씨', '비');
insert into user_data(user_id, user_pwd) values('admin', '1111');


